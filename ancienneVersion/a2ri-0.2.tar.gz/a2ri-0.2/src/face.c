/*************************************/
/* Auteur : Rémi Synave              */
/* Date de création : 01/03/07       */
/* Date de modification : 08/01/10   */
/* Version : 0.2                     */
/*************************************/

/***************************************************************************/
/* This file is part of a2ri.                                              */
/*                                                                         */
/* a2ri is free software: you can redistribute it and/or modify it         */
/* under the terms of the GNU Lesser General Public License as published   */
/* by the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                     */
/*                                                                         */
/* a2ri is distributed in the hope that it will be useful,                 */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/* GNU Lesser General Public License for more details.                     */
/*                                                                         */
/* You should have received a copy of the GNU Lesser General Public        */
/* License along with a2ri.                                                */
/* If not, see <http://www.gnu.org/licenses/>.                             */
/***************************************************************************/

#include "face.h"

/********** INTERMEDIATE TYPES AND FUNCTIONS **********/
/* Les fonctions intermédiaires sont préfixées de IF  */
/* et les types intermédiaires de IT                  */

/********** MAIN FUNCTIONS **********/

/**
   Affichage d'une face
   @param f face à afficher
   @return aucun
*/
void
vf_face_display (
		 vf_face f)
{
  printf ("Face --> [vertex %d , edge %d , edge %d]\n", f.ve1, f.ve2, f.ve3);
}

/**
   Inversion de l'orientation de la face
   @param f pointeur sur la face à inverser
   @return aucun
*/
void
vf_face_reverse (
		 vf_face * f)
{
  int temp = f->ve1;
  f->ve1 = f->ve2;
  f->ve2 = temp;
}

/**
   Test de l'appartenance d'un sommet à une face
   @param f pointeur sur la face
   @param numvertex numero du sommet
   @return 1 si le sommet appartient à la face, 0 sinon
*/
int
vf_face_contains (
		  vf_face * f,
		  int numvertex)
{
  return (f->ve1 == numvertex || f->ve2 == numvertex || f->ve3 == numvertex);
}


/**
   Libération de la mémoire
   @param f la vf_face
   @return aucun
**/
void
vf_face_free (
	      vf_face * f)
{
  free (f->sharedpolyhedrons);
}





/**
   Affichage d'une face
   @param f face à afficher
   @return aucun
*/
void
vef_face_display (
		  vef_face f)
{
  printf ("Face --> [vertex %d , edge %d , edge %d]\n", f.ed1, f.ed2, f.ed3);
}

/**
   Inversion de l'orientation de la face
   @param f pointeur sur la face à inverser
   @return aucun
*/
void
vef_face_reverse (
		  vef_face * f)
{
  int temp = f->ed1;
  f->ed1 = f->ed2;
  f->ed2 = temp;
}

/**
   Donne les trois points formant la face
   @param f la face dont on veut les trois sommets
   @param list list des aretes
   @param ve1 index du premier sommet
   @param ve2 index du second sommet
   @param ve3 index du troisième sommet
   @return aucun
*/
void
vef_face_get_vertices (
		       vef_face f,
		       vef_edge * list,
		       int *ve1,
		       int *ve2,
		       int *ve3)
{
  if (list[f.ed1].ve1 == list[f.ed2].ve1
      || list[f.ed1].ve1 == list[f.ed2].ve2)
    {
      *ve1 = list[f.ed1].ve1;
      *ve3 = list[f.ed1].ve2;
    }
  else
    {
      *ve1 = list[f.ed1].ve2;
      *ve3 = list[f.ed1].ve1;
    }
  if (list[f.ed2].ve1 == list[f.ed3].ve1
      || list[f.ed2].ve1 == list[f.ed3].ve2)
    *ve2 = list[f.ed2].ve1;
  else
    *ve2 = list[f.ed2].ve2;
}

/**
   Test de l'appartenance d'une arete à une face
   @param f pointeur sur la face
   @param numvertex numero de l'arete
   @return 1 si l'arete appartient à la face, 0 sinon
*/
int
vef_face_contains (
		   vef_face * f,
		   int numedge)
{
  return (f->ed1 == numedge || f->ed2 == numedge || f->ed3 == numedge);
}


/**
   Libération de la mémoire
   @param f la vef_face
   @return aucun
**/
void
vef_face_free (
	       vef_face * f)
{
  free (f->sharedpolyhedrons);
}
