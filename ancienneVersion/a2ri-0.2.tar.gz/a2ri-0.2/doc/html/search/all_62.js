var searchData=
[
  ['bpa_5fedge',['bpa_edge',['../structbpa__edge.html',1,'']]],
  ['bpa_5ffronts',['bpa_fronts',['../structbpa__fronts.html',1,'']]]
];
