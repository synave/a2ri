/*************************************/
/* Auteur : Rémi Synave              */
/* Date de création : 10/03/10       */
/* Date de modification : 10/03/10   */
/* Version : 0.2                     */
/*************************************/

/***************************************************************************/
/* This file is part of a2ri.                                              */
/*                                                                         */
/* a2ri is free software: you can redistribute it and/or modify it         */
/* under the terms of the GNU Lesser General Public License as published   */
/* by the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                     */
/*                                                                         */
/* a2ri is distributed in the hope that it will be useful,                 */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/* GNU Lesser General Public License for more details.                     */
/*                                                                         */
/* You should have received a copy of the GNU Lesser General Public        */
/* License along with a2ri.                                                */
/* If not, see <http://www.gnu.org/licenses/>.                             */
/***************************************************************************/

#ifndef IO__H
#define IO__H

#include <locale.h>
#include "model.h"

/**
   Ouverture d'un fichier contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_open_file (
		       char *file,
		       vf_model * m);

/**
   Ouverture d'un fichier asc contenant un nuage de points
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_asc (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier vef contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_vef (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier gts contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_gts (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier pgn contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_pgn (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier off contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_off (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier ply contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_ply (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier wrl contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_wrl (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier obj contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_obj (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier stl contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_stl (
		      char *file,
		      vf_model * m);

/**
   Ouverture d'un fichier stl binaire contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_binary_stl (
			     char *file,
			     vf_model * m);

/**
   Ouverture d'un fichier stl ascii contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_ascii_stl (
			    char *file,
			    vf_model * m);

/**
   Ouverture d'un fichier tet contenant un modèle
   @param file chemin du fichier à ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_load_tet (
		      char *file,
		      vf_model * m);

/**
   Enregistrement d'un modèle dans un format défini par l'extension du nom de fichier
   @param file nom du fichier
   @param m le modèle
   @return aucun
*/
int a2ri_vf_save_file (
		       char *file,
		       vf_model m);

/**
   Enregistrement d'un modèle dans un fichier vef
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_vef (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier gts
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_gts (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier pgn
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_pgn (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier off
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_off (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier ply
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_ply (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier wrl
   @param file chemin du fichier
   @param m modèle à sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_wrl (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier wrl version 1.0
   @param file chemin du fichier
   @param m modèle à sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_wrl_v1 (
			 char *file,
			 vf_model m);

/**
   Enregistrement d'un modèle dans un fichier obj
   @param file chemin du fichier
   @param m modèle à sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_obj (
		      char *file,
		      vf_model m);

/**
   Enregistrement d'un modèle dans un fichier stl
   @param file chemin du fichier
   @param m modèle à sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vf_save_stl (
		      char *file,
		      vf_model m);

/**
   Ouverture d'un fichier contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_open_file (
			char *file,
			vef_model * m);

/**
   Ouverture d'un fichier vef contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_vef (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier gts contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_gts (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier pgn contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_pgn (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier stl contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_stl (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier tet contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_tet (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier off contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_off (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier ply contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_ply (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier wrl contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_wrl (
		       char *file,
		       vef_model * m);

/**
   Ouverture d'un fichier obj contenant un modèle
   @param file chemin du fichier à  ouvrir
   @param m pointeur sur le modèle
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_load_obj (
		       char *file,
		       vef_model * m);

/**
   Enregistrement d'un modèle dans un format défini par l'extension du nom de fichier
   @param file nom du fichier
   @param m le modèle
   @return aucun
*/
int a2ri_vef_save_file (
			char *file,
			vef_model m);

/**
   Enregistrement d'un modèle dans un fichier vef
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_vef (
		       char *file,
		       vef_model m);

/**
   Enregistrement d'un modèle dans un fichier gts
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_gts (
		       char *file,
		       vef_model m);

/**
   Enregistrement d'un modèle dans un fichier pgn
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_pgn (
		       char *file,
		       vef_model m);

/**
   Enregistrement d'un modèle dans un fichier off
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_off (
		       char *file,
		       vef_model m);

/**
   Enregistrement d'un modèle dans un fichier ply
   @param file chemin du fichier
   @param m modèle à  sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_ply (
		       char *file,
		       vef_model m);

/**
   Enregistrement d'un modèle dans un fichier wrl
   @param file chemin du fichier
   @param m modèle à sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_wrl (
		       char *file,
		       vef_model m);

/**
   Enregistrement d'un modèle dans un fichier obj
   @param file chemin du fichier
   @param m modèle à sauvegarder
   @return 1 si succès, 0 sinon
*/
int a2ri_vef_save_obj (
		       char *file,
		       vef_model m);

#endif
