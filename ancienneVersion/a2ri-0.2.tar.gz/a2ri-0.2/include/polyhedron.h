/*************************************/
/* Auteur : Rémi Synave              */
/* Date de création : 20/03/08       */
/* Date de modification : 08/01/10   */
/* Version : 0.2                     */
/*************************************/

/***************************************************************************/
/* This file is part of a2ri.                                              */
/*                                                                         */
/* a2ri is free software: you can redistribute it and/or modify it         */
/* under the terms of the GNU Lesser General Public License as published   */
/* by the Free Software Foundation, either version 3 of the License, or    */
/* (at your option) any later version.                                     */
/*                                                                         */
/* a2ri is distributed in the hope that it will be useful,                 */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of          */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           */
/* GNU Lesser General Public License for more details.                     */
/*                                                                         */
/* You should have received a copy of the GNU Lesser General Public        */
/* License along with a2ri.                                                */
/* If not, see <http://www.gnu.org/licenses/>.                             */
/***************************************************************************/



#ifndef POLYHEDRON__H
#define POLYHEDRON__H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct
{
  int fa1;
  int fa2;
  int fa3;
  int fa4;
} polyhedron;

/**
   Affichage d'un polyhedre
   @param f face à afficher
   @return aucun
*/
void polyhedron_display (
			 polyhedron p);

#endif
